import { Factura } from "./factura.entity";

describe('FacturaEntity', () => {
  it('should be defined', () => {
    expect(new Factura()).toBeDefined();
  });
});
